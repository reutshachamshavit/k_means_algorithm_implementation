from setuptools import Extension, setup

module = Extension(
    "symnmf",
    sources=['symnmfmodule.c', 'symnmf.c'],
)

setup(
    name='symnmf',
    version='1.0',
    description='SymNMF C extension for Python',
    ext_modules=[module]
)