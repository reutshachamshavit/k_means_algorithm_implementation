import sys
import math
import numpy as np
import symnmf
from sklearn.metrics import silhouette_score

def print_error_and_exit(msg: str = "An Error Has Occurred") -> None:
    print(msg)
    sys.exit(1)

def is_int_str(s: str) -> bool:
    return s.isdigit()

def read_file_to_matrix(path: str):
    data = []
    with open(path, "r") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split(",")
            try:
                vec = [float(x) for x in parts]
                data.append(vec)
            except Exception:
                raise ValueError("bad input")
    return data

# ==========================================
# K-means Helpers (Adapted from HW1)
# ==========================================
def euclidean_distance(p, q):
    return math.sqrt(sum((pi - qi) ** 2 for pi, qi in zip(p, q)))

def init_centroids(points, k):
    return [p[:] for p in points[:k]]

def assign_points_to_clusters(points, centroids):
    assignments = []
    for p in points:
        min_dist = None
        min_index = None
        for idx, c in enumerate(centroids):
            d = euclidean_distance(p, c)
            if (min_dist is None) or (d < min_dist):
                min_dist = d
                min_index = idx
        assignments.append(min_index)
    return assignments

def update_centroids(points, assignments, centroids, k):
    dim = len(points[0])
    sums = [[0.0] * dim for _ in range(k)]
    counts = [0] * k

    for p, cluster_idx in zip(points, assignments):
        counts[cluster_idx] += 1
        for i in range(dim):
            sums[cluster_idx][i] += p[i]

    new_centroids = []
    for idx in range(k):
        if counts[idx] == 0:
            new_centroids.append(centroids[idx][:])
        else:
            new_centroids.append([sums[idx][i] / counts[idx] for i in range(dim)])
    return new_centroids

def has_converged(prev_centroids, curr_centroids, eps):
    for prev, curr in zip(prev_centroids, curr_centroids):
        if euclidean_distance(prev, curr) >= eps:
            return False
    return True

def run_kmeans(points, k, max_iter=300, eps=1e-4):
    centroids = init_centroids(points, k)
    for _ in range(max_iter):
        assignments = assign_points_to_clusters(points, centroids)
        new_centroids = update_centroids(points, assignments, centroids, k)

        if has_converged(centroids, new_centroids, eps):
            centroids = new_centroids
            break
        centroids = new_centroids
    return centroids

# ==========================================
# Main Execution
# ==========================================
def main() -> None:
    argv = sys.argv
    if len(argv) != 3:
        print_error_and_exit()

    k_str = argv[1]
    file_name = argv[2]

    if not is_int_str(k_str):
        print_error_and_exit()
    k = int(k_str)

    try:
        data = read_file_to_matrix(file_name)
        X = np.array(data, dtype=float)
    except Exception:
        print_error_and_exit()

    n = X.shape[0]
    if not (1 <= k < n):
        print_error_and_exit()

    points = X.tolist()
    
    # 1. SymNMF Clustering
    np.random.seed(1234)
    try:
        W_mat = symnmf.norm(points)
        W = np.array(W_mat)
        m = np.mean(W)

        high = 2.0 * np.sqrt(m / k)
        initial_H = np.random.uniform(low=0.0, high=high, size=(n, k))

        final_H_mat = symnmf.symnmf(initial_H.tolist(), W_mat)
        if final_H_mat is None:
            print_error_and_exit()
            
        final_H = np.array(final_H_mat)
        symnmf_labels = np.argmax(final_H, axis=1)
        
    except Exception:
        print_error_and_exit()

    # 2. HW1 K-means Clustering
    try:
        # Using iter=300 and eps=1e-4 as required by section 2.9.8
        final_centroids = run_kmeans(points, k, max_iter=300, eps=1e-4)
        
        # We can reuse your HW1 assignment function to get the final labels for silhouette_score
        kmeans_labels_list = assign_points_to_clusters(points, final_centroids)
        kmeans_labels = np.array(kmeans_labels_list)
        
    except Exception:
        print_error_and_exit()

    # 3. Calculate and Print Silhouette Scores
    try:
        nmf_score = silhouette_score(X, symnmf_labels)
        kmeans_score = silhouette_score(X, kmeans_labels)
        
        print(f"nmf: {nmf_score:.4f}")
        print(f"kmeans: {kmeans_score:.4f}")
    except Exception:
        print_error_and_exit()

if __name__ == "__main__":
    main()