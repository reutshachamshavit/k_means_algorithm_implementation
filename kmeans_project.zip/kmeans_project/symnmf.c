#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "symnmf.h"

/* Optimization parameters as defined in the assignment */
#define EPSILON 1e-4
#define MAX_ITER 300

/* Helper: Standardized error exit per assignment instructions */
static void die() {
    printf("An Error Has Occurred\n");
    exit(1);
}

/* Helper: Safely frees a 2D matrix to prevent memory leaks */
static void free_mat(double **mat, int n) {
    int i;
    if (!mat) return;
    for (i = 0; i < n; i++) free(mat[i]);
    free(mat);
}

/* Helper: Allocates a 2D matrix of size n x d and initializes with 0.0 */
static double **alloc_mat(int n, int d) {
    double **mat;
    int i, j;
    mat = (double **)malloc(n * sizeof(double *));
    if (!mat) die();
    for (i = 0; i < n; i++) {
        mat[i] = (double *)malloc(d * sizeof(double));
        if (!mat[i]) die();
        for (j = 0; j < d; j++) mat[i][j] = 0.0;
    }
    return mat;
}

/* Helper: Calculates the squared Euclidean distance between two vectors */
static double sq_dist(double *p1, double *p2, int d) {
    double sum = 0.0, diff;
    int i;
    for (i = 0; i < d; i++) {
        diff = p1[i] - p2[i];
        sum += diff * diff;
    }
    return sum;
}

/* Helper: Multiplies matrix A (n x m) and matrix B (m x p) to return C (n x p) */
static double **mat_mult(double **A, double **B, int n, int m, int p) {
    double **C = alloc_mat(n, p);
    int i, j, k;
    for (i = 0; i < n; i++) {
        for (j = 0; j < p; j++) {
            for (k = 0; k < m; k++) {
                C[i][j] += A[i][k] * B[k][j];
            }
        }
    }
    return C;
}

/* Helper: Returns the transpose of matrix A (n x d) -> T (d x n) */
static double **transpose(double **A, int n, int d) {
    double **T = alloc_mat(d, n);
    int i, j;
    for (i = 0; i < n; i++) {
        for (j = 0; j < d; j++) {
            T[j][i] = A[i][j];
        }
    }
    return T;
}

/* Step 1.1: Calculate the Similarity Matrix (A)
   Formula: a_ij = exp(- ||x_i - x_j||^2 / 2) if i != j, and a_ii = 0 */
double **sym(double **X, int n, int d) {
    double **A = alloc_mat(n, n);
    int i, j;
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            if (i != j) {
                A[i][j] = exp(-sq_dist(X[i], X[j], d) / 2.0);
            }
        }
    }
    return A;
}

/* Step 1.2: Calculate the Diagonal Degree Matrix (D)
   Formula: d_i = sum of all a_ij in row i. The rest of the matrix is 0. */
double **ddg(double **X, int n, int d) {
    double **D = alloc_mat(n, n);
    double **A = sym(X, n, d);
    int i, j;
    for (i = 0; i < n; i++) {
        double sum = 0.0;
        for (j = 0; j < n; j++) {
            sum += A[i][j];
        }
        D[i][i] = sum;
    }
    free_mat(A, n);
    return D;
}

/* Step 1.3: Calculate the Normalized Similarity Matrix (W)
   Formula: W = D^(-1/2) * A * D^(-1/2) */
double **norm(double **X, int n, int d) {
    double **W = alloc_mat(n, n);
    double **A = sym(X, n, d);
    double *deg = (double *)malloc(n * sizeof(double));
    int i, j;
    if (!deg) die();
    
    /* Calculate D^(-1/2) and store it in a 1D array to save memory/time */
    for (i = 0; i < n; i++) {
        deg[i] = 0.0;
        for (j = 0; j < n; j++) deg[i] += A[i][j];
        deg[i] = 1.0 / sqrt(deg[i]);
    }
    
    /* Compute W using the degree array: w_ij = a_ij * d^(-1/2)_i * d^(-1/2)_j */
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            W[i][j] = A[i][j] * deg[i] * deg[j];
        }
    }
    free(deg);
    free_mat(A, n);
    return W;
}

/* Step 1.4: Optimize the H matrix using iterative updates
   Formula: H_new = H * (1 - beta + beta * (WH / (H * H^T * H))) where beta = 0.5 */
double **symnmf(double **H, double **W, int n, int k) {
    int iter, i, j;
    double diff = 1.0;
    double **H_new = alloc_mat(n, k);
    double **res = alloc_mat(n, k);
    
    /* Loop until max iterations reached OR squared Frobenius norm diff < EPSILON */
    for (iter = 0; iter < MAX_ITER && diff >= EPSILON; iter++) {
        /* Precompute multiplications. We use H*(H^T*H) instead of (H*H^T)*H 
           to avoid creating an O(n^2) matrix, making it incredibly fast. */
        double **Ht = transpose(H, n, k);
        double **HtH = mat_mult(Ht, H, k, n, k);
        double **HHtH = mat_mult(H, HtH, n, k, k);
        double **WH = mat_mult(W, H, n, n, k);
        
        diff = 0.0;
        /* Update rule with beta = 0.5 */
        for (i = 0; i < n; i++) {
            for (j = 0; j < k; j++) {
                H_new[i][j] = H[i][j] * (0.5 + 0.5 * (WH[i][j] / HHtH[i][j]));
                
                /* Calculate squared Frobenius norm difference on the fly */
                diff += (H_new[i][j] - H[i][j]) * (H_new[i][j] - H[i][j]);
            }
        }
        
        /* Free intermediate matrices for this iteration to prevent leaks */
        free_mat(Ht, k); free_mat(HtH, k); 
        free_mat(HHtH, n); free_mat(WH, n);
        
        /* Copy updated H_new into H for the next iteration */
        for (i = 0; i < n; i++) {
            for (j = 0; j < k; j++) H[i][j] = H_new[i][j];
        }
    }
    
    /* Copy the final converged H matrix into the result matrix */
    for (i = 0; i < n; i++) {
        for (j = 0; j < k; j++) res[i][j] = H[i][j];
    }
    free_mat(H_new, n);
    return res;
}

/* ==========================================================
   Standalone C Executable Wrapper (ignored when imported by Python)
   ========================================================== */
#ifndef PYTHON_MODULE

/* Helper: Prints a matrix separated by commas, formatted to 4 decimal places */
static void print_mat(double **mat, int rows, int cols) {
    int i, j;
    for (i = 0; i < rows; i++) {
        for (j = 0; j < cols; j++) {
            if (j < cols - 1) printf("%.4f,", mat[i][j]);
            else printf("%.4f\n", mat[i][j]);
        }
    }
}

/* Helper: Dynamically reads the input text file into a 2D matrix */
static double **read_file(const char *path, int *n, int *d) {
    FILE *fp; char line[2048], *tok;
    double **data = malloc(100 * sizeof(double*));
    int cap = 100, i;
    *n = 0; *d = 0;
    
    if (!(fp = fopen(path, "r")) || !data) die();
    while (fgets(line, sizeof(line), fp)) {
        /* Determine dimension 'd' by counting commas in the first line */
        if (*d == 0) {
            char tmp[2048]; strcpy(tmp, line);
            tok = strtok(tmp, ",");
            while (tok) { (*d)++; tok = strtok(NULL, ","); }
        }
        
        /* Double the row capacity if we run out of space */
        if (*n == cap) {
            cap *= 2; data = realloc(data, cap * sizeof(double*));
            if (!data) die();
        }
        
        /* Allocate the row and parse the floats */
        data[*n] = malloc(*d * sizeof(double));
        if (!data[*n]) die();
        tok = strtok(line, ",");
        for (i = 0; i < *d; i++) {
            data[*n][i] = atof(tok); tok = strtok(NULL, ",");
        }
        (*n)++;
    }
    fclose(fp);
    return data;
}

/* Main execution for the standalone C program */
int main(int argc, char **argv) {
    int n, d;
    double **X, **res = NULL;
    
    /* We expect exactly 3 arguments: ./symnmf <goal> <file_name> */
    if (argc != 3) die();
    
    /* Read the data points */
    X = read_file(argv[2], &n, &d);
    
    /* Route to the correct mathematical operation based on the goal arg */
    if (strcmp(argv[1], "sym") == 0) res = sym(X, n, d);
    else if (strcmp(argv[1], "ddg") == 0) res = ddg(X, n, d);
    else if (strcmp(argv[1], "norm") == 0) res = norm(X, n, d);
    else die(); /* Goal was invalid */

    /* Output the final matrix and clean up memory */
    print_mat(res, n, n);
    free_mat(res, n);
    free_mat(X, n);
    
    return 0;
}
#endif