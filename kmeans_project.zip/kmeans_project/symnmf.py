import sys
import numpy as np
import symnmf

def print_error_and_exit(msg: str = "An Error Has Occurred") -> None:
    print(msg)
    sys.exit(1)

def is_int_str(s: str) -> bool:
    return s.isdigit()

def read_file_to_matrix(path: str):
    data = []
    with open(path, "r") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split(",")
            try:
                vec = [float(x) for x in parts]
                data.append(vec)
            except Exception:
                raise ValueError("bad input")
    return data

def main() -> None:
    argv = sys.argv
    if len(argv) != 4:
        print_error_and_exit()

    k_str = argv[1]
    goal = argv[2]
    file_name = argv[3]

    if not is_int_str(k_str):
        print_error_and_exit("An Error Has Occurred")
    k = int(k_str)

    valid_goals = {"symnmf", "sym", "ddg", "norm"}
    if goal not in valid_goals:
        print_error_and_exit()

    # Read data
    try:
        data = read_file_to_matrix(file_name)
        X = np.array(data, dtype=float)
    except Exception:
        print_error_and_exit()

    n = X.shape[0]
    
    # Validate K 
    if not (1 <= k < n):
        print_error_and_exit()

    points = X.tolist()

    try:
        if goal == "sym":
            result = symnmf.sym(points)
            
        elif goal == "ddg":
            result = symnmf.ddg(points)
            
        elif goal == "norm":
            result = symnmf.norm(points)
            
        elif goal == "symnmf":
            # 1. Get the normalized similarity matrix W
            W_mat = symnmf.norm(points)
            W = np.array(W_mat)

            # 2. Calculate m (average of all entries of W)
            m = np.mean(W)

            # 3. Initialize H randomly
            np.random.seed(1234)
            high = 2.0 * np.sqrt(m / k)
            initial_H = np.random.uniform(low=0.0, high=high, size=(n, k))

            # 4. Pass initial_H and W to C extension for optimization
            result = symnmf.symnmf(initial_H.tolist(), W_mat)
            
    except Exception:
        print_error_and_exit()

    if result is None:
        print_error_and_exit()

    # Print output matrix with 4 decimals
    for row in result:
        print(",".join(f"{float(val):.4f}" for val in row))

if __name__ == "__main__":
    main()