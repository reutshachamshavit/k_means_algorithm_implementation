#define PY_SSIZE_T_CLEAN
#include <Python.h>
#include <stdlib.h>
#include "symnmf.h" 

static void free_matrix(double **m, int rows) {
    int i;
    if (!m) return;
    for (i = 0; i < rows; i++) free(m[i]);
    free(m);
}

static double **pylist_to_matrix(PyObject *lst, int rows, int cols) {
    int i, j;
    double **mat = malloc(rows * sizeof(double*));
    if (!mat) return NULL;

    for (i = 0; i < rows; i++) {
        PyObject *row = PyList_GetItem(lst, i); 
        if (!PyList_Check(row) || (int)PyList_Size(row) != cols) {
            for (j = 0; j < i; j++) free(mat[j]);
            free(mat);
            PyErr_SetString(PyExc_RuntimeError, "An Error Has Occurred");
            return NULL;
        }
        mat[i] = malloc(cols * sizeof(double));
        if (!mat[i]) {
            for (j = 0; j < i; j++) free(mat[j]);
            free(mat);
            return NULL;
        }
        for (j = 0; j < cols; j++) {
            PyObject *val = PyList_GetItem(row, j);
            double x = PyFloat_AsDouble(val);
            if (PyErr_Occurred()) {
                for (int t = 0; t <= i; t++) free(mat[t]);
                free(mat);
                return NULL;
            }
            mat[i][j] = x;
        }
    }
    return mat;
}

/* Helper for sym, ddg, and norm to stay under 40 lines */
static PyObject *process_graph_matrix(PyObject *args, double **(*c_func)(double **, int, int)) {
    PyObject *py_pts, *py_out, *f_row;
    int n, dim, i, j;
    double **pts, **out;

    if (!PyArg_ParseTuple(args, "O", &py_pts)) return NULL;
    if (!PyList_Check(py_pts) || PyList_Size(py_pts) == 0) {
        PyErr_SetString(PyExc_RuntimeError, "An Error Has Occurred"); return NULL;
    }

    n = (int)PyList_Size(py_pts);
    f_row = PyList_GetItem(py_pts, 0);
    if (!PyList_Check(f_row)) {
        PyErr_SetString(PyExc_RuntimeError, "An Error Has Occurred"); return NULL;
    }
    
    dim = (int)PyList_Size(f_row);
    pts = pylist_to_matrix(py_pts, n, dim);
    if (!pts) { PyErr_SetString(PyExc_RuntimeError, "An Error Has Occurred"); return NULL; }
    
    out = c_func(pts, n, dim);
    free_matrix(pts, n);
    if (!out) { PyErr_SetString(PyExc_RuntimeError, "An Error Has Occurred"); return NULL; }

    py_out = PyList_New(n);
    if (!py_out) { free_matrix(out, n); return NULL; }
    for (i = 0; i < n; i++) {
        PyObject *row = PyList_New(n);
        if (!row) { Py_DECREF(py_out); free_matrix(out, n); return NULL; }
        for (j = 0; j < n; j++) {
            PyObject *f = PyFloat_FromDouble(out[i][j]);
            if (!f) { Py_DECREF(row); Py_DECREF(py_out); free_matrix(out, n); return NULL; }
            PyList_SetItem(row, j, f);
        }
        PyList_SetItem(py_out, i, row);
    }
    
    free_matrix(out, n);
    return py_out;
}

static PyObject *sym_api(PyObject *self, PyObject *args) {
    (void)self;
    return process_graph_matrix(args, sym);
}

static PyObject *ddg_api(PyObject *self, PyObject *args) {
    (void)self;
    return process_graph_matrix(args, ddg);
}

static PyObject *norm_api(PyObject *self, PyObject *args) {
    (void)self;
    return process_graph_matrix(args, norm);
}

static PyObject *symnmf_api(PyObject *self, PyObject *args) {
    PyObject *py_H, *py_W, *py_out, *f_row;
    int n, k, i, j;
    double **H, **W, **out;
    (void)self;

    if (!PyArg_ParseTuple(args, "OO", &py_H, &py_W)) return NULL;
    if (!PyList_Check(py_H) || PyList_Size(py_H) == 0 || !PyList_Check(py_W)) {
        PyErr_SetString(PyExc_RuntimeError, "An Error Has Occurred"); return NULL;
    }

    n = (int)PyList_Size(py_H);
    f_row = PyList_GetItem(py_H, 0);
    if (!PyList_Check(f_row)) {
        PyErr_SetString(PyExc_RuntimeError, "An Error Has Occurred"); return NULL;
    }
    k = (int)PyList_Size(f_row);

    H = pylist_to_matrix(py_H, n, k);
    W = pylist_to_matrix(py_W, n, n);
    if (!H || !W) {
        free_matrix(H, n); free_matrix(W, n);
        PyErr_SetString(PyExc_RuntimeError, "An Error Has Occurred"); return NULL;
    }

    out = symnmf(H, W, n, k);
    free_matrix(H, n);
    free_matrix(W, n);
    if (!out) { PyErr_SetString(PyExc_RuntimeError, "An Error Has Occurred"); return NULL; }

    py_out = PyList_New(n);
    if (!py_out) { free_matrix(out, n); return NULL; }
    for (i = 0; i < n; i++) {
        PyObject *row = PyList_New(k);
        if (!row) { Py_DECREF(py_out); free_matrix(out, n); return NULL; }
        for (j = 0; j < k; j++) {
            PyObject *f = PyFloat_FromDouble(out[i][j]);
            if (!f) { Py_DECREF(row); Py_DECREF(py_out); free_matrix(out, n); return NULL; }
            PyList_SetItem(row, j, f);
        }
        PyList_SetItem(py_out, i, row);
    }

    free_matrix(out, n);
    return py_out;
}

static PyMethodDef Methods[] = {
    {"sym", (PyCFunction)sym_api, METH_VARARGS, PyDoc_STR("Calculate similarity matrix")},
    {"ddg", (PyCFunction)ddg_api, METH_VARARGS, PyDoc_STR("Calculate diagonal degree matrix")},
    {"norm", (PyCFunction)norm_api, METH_VARARGS, PyDoc_STR("Calculate normalized similarity matrix")},
    {"symnmf", (PyCFunction)symnmf_api, METH_VARARGS, PyDoc_STR("Optimize H matrix")},
    {NULL, NULL, 0, NULL}
};

static struct PyModuleDef moduledef = {
    PyModuleDef_HEAD_INIT,
    "symnmf",
    NULL,
    -1,
    Methods
};

PyMODINIT_FUNC PyInit_symnmf(void) {
    return PyModule_Create(&moduledef);
}